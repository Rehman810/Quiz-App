var Name = document.getElementById("name");
var userName = localStorage.getItem("User Name");

Name.innerHTML ="Hi, " + userName;